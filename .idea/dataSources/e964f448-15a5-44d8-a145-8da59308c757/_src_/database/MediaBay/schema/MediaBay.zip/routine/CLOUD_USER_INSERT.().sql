create function "MediaBay"."CLOUD_USER_INSERT"() returns TABLE(cloud_users_inserted integer, ref_geo_id_inserted integer, cloud_user_addresses_inserted integer, cloud_user_resumes_inserted integer, cloud_resume_additional_infos_added integer, state_id_updates integer, channel_id_updates integer)
LANGUAGE plpgsql
AS $$
DECLARE
		cloud_users_inserted integer;
		ref_geo_id_inserted integer;
		state_id_updates integer;
		channel_id_updates integer;
		cloud_user_addresses_inserted integer;
		cloud_user_resumes_inserted integer;
		cloud_resume_additional_infos_added integer;
		BEGIN
				-- USER STATE INSERT
				INSERT INTO "MediaBay"."REF.JS.USER.COUNTRY.STATE.DETAILS" (state_id, state_name, state_abb, country_id, message_id, state_abb_message_id, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (state_id) state_id, state_name, state_abb, country_id, message_id, state_abb_message_id, date_modified, etl_date, datasource_id
				FROM "MediaBay"."REF.STG.USER.STATE.DETAILS";
				--ON CONFLICT ON CONSTRAINT state_id DO NOTHING;
				GET DIAGNOSTICS state_id_updates = ROW_COUNT;
				
				-- CHANNEL ID
				INSERT INTO "MediaBay"."REF.JS.USER.CHANNEL.DETAILS" (channel_id, channel_name, channel_alias, country_id, language_id, apply_online_url, private, root_site, iso_locale, parent_channel_id, allow_job_posts_to_all_company_boards, resume_actions_are_private,
				channel_accessibility, channel_type_id, channel_status_id, chs_report, month_until_resume_expires_on_channel, etl_date, datasource_id)
				SELECT DISTINCT ON (channel_id) channel_id, channel_name, channel_alias, country_id, language_id, apply_online_url, private, root_site, iso_locale, parent_channel_id, allow_job_posts_to_all_company_boards, resume_actions_are_private,
				channel_accessibility, channel_type_id, channel_status_id, chs_report, month_until_resume_expires_on_channel, etl_date, datasource_id
				FROM "MediaBay"."REF.STG.USER.CHANNEL.DETAILS"
				ON CONFLICT ON CONSTRAINT channel_pkey DO NOTHING;
				GET DIAGNOSTICS channel_id_updates = ROW_COUNT;
				
						--CLOUD USER INFO DETAILS INSERT
						INSERT INTO "MediaBay"."CLOUD_(01)_UserInfoDetails" (user_id, database_contex_id, username, name_prefix_id, first_name, middle_name, last_name, name_suffix, email_address, country_id, state_id, city, address1, address2, postal_code, us_zip5, location_id, confidential, 
						disabled, channel_id, career_level_id, available_time_id, available_day, available_month, available_year, daytime_phone, evening_phone, mobile_phone, fax, pager, company, date_created, date_modified, date_deleted, etl_date, created_channel_id, datasource_id)
						SELECT DISTINCT ON (user_id, datasource_id) user_id, database_contex_id, username, name_prefix_id, initcap (trim(both ' ' from first_name)), initcap (trim(both ' ' from middle_name)), initcap (trim(both ' ' from last_name)), trim(both ' ' from name_suffix), trim(both ' ' from email_address), country_id, state_id, 
						initcap (trim(both ' ' from city)), initcap (trim(both ' ' from address1)), initcap (trim(both ' ' from address2)), trim(both ' ' from postal_code), trim(both ' ' from us_zip5), location_id, confidential, disabled, channel_id, career_level_id, available_time_id, available_day, available_month, available_year, 
						trim(both ' ' from daytime_phone), trim(both ' ' from evening_phone), trim(both ' ' from mobile_phone), trim(both ' ' from fax), trim(both ' ' from pager), trim(both ' ' from company), date_created, date_modified, date_deleted, etl_date, created_channel_id, datasource_id
						FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails"
						ON CONFLICT ON CONSTRAINT cloud_user_info_pkey DO NOTHING;
						GET DIAGNOSTICS cloud_users_inserted = ROW_COUNT;

				--REF GEO
				INSERT INTO "MediaBay"."REF.JS.USER.REF.GEO.DETAILS" (ref_geo_id, parent_ref_geo_id, geo_name, geo_type_id, message_id, latitude, longitude, date_modified, population_tier_id, displayable, datasource_id, date_deleted)
				SELECT DISTINCT ON (ref_geo_id) ref_geo_id, parent_ref_geo_id, geo_name, geo_type_id, message_id, latitude, longitude, date_modified, population_tier_id, displayable, datasource_id, date_deleted
				FROM "MediaBay"."REF.STG.REF.GEO.DETAILS" ST
					WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."REF.JS.USER.REF.GEO.DETAILS" RT WHERE RT.ref_geo_id = ST.ref_geo_id);
					GET DIAGNOSTICS ref_geo_id_inserted = ROW_COUNT;
					
						--CLOUD USER ADDRESS INSERT
						INSERT INTO "MediaBay"."CLOUD_(02)_UserAddressDetails" (user_id, address_type_id, verified_id, address1, address2, city, postal_code, ref_geo_id, preferred_method, modified_date, datasource_id)
						SELECT DISTINCT ON (user_id, address_type_id, datasource_id) user_id, address_type_id, verified_id, initcap(trim(both ' ' from address1)), initcap(trim(both ' ' from address2)), initcap(trim(both ' ' from city)), trim(both ' ' from postal_code), ref_geo_id, preferred_method, modified_date, datasource_id
						FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
							WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(02)_UserAddressDetails" RT WHERE RT.user_id = ST.user_id AND RT.address_type_id = ST.address_type_id)
							AND
							EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(01)_UserInfoDetails" VT WHERE VT.user_id = ST.user_id);
							GET DIAGNOSTICS cloud_user_addresses_inserted = ROW_COUNT;
							
				--CLOUD USER RESUME INSERT
				INSERT INTO "MediaBay"."CLOUD_(03)_UserResumeDetails" (resume_id, database_context_id, user_id, wants_permanent, wants_contract, wants_intern, wants_temp, wants_fulltime, wants_parttime, salary, salary_type_id, currency_id, site_location_id, commute_distance, distance_id, company_size_id,
				category_id, resume_title, date_created, date_modified, will_relocate, date_expires, channel_id, active, date_deleted, builder_id, created_channel_id, hourly, wants_perdiem, wants_overtime, wants_weekends, prefer_weekends, date_sequential, salary_from, salary_from_normalised, etl_date, datasource_id, source_id)
				SELECT DISTINCT ON (resume_id, datasource_id) resume_id, database_context_id, user_id, wants_permanent, wants_contract, wants_intern, wants_temp, wants_fulltime, wants_parttime, salary, salary_type_id, currency_id, site_location_id, commute_distance, distance_id, company_size_id,
				category_id, trim(both ' ' from resume_title), date_created, date_modified, will_relocate, date_expires, channel_id, active, date_deleted, builder_id, created_channel_id, hourly, wants_perdiem, wants_overtime, wants_weekends, prefer_weekends, date_sequential, salary_from, salary_from_normalised, 
				etl_date, datasource_id, source_id
				FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
				WHERE
					EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(01)_UserInfoDetails" RT1 WHERE ST.user_id = RT1.user_id)
					AND
					NOT EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(03)_UserResumeDetails" RT2 WHERE ST.resume_id = RT2.resume_id);
				GET DIAGNOSTICS cloud_user_resumes_inserted = ROW_COUNT;

						-- CLOUD USER RESUME ADDITIONAL INFOS ADDED
						INSERT INTO "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" (resume_id, database_context_id, has_pl_experience, largest_budget_answer_id, number_people_managed_answer_id, has_turn_arround_experience, turnarround_experience, has_ipo_experience, ipo_experience, 
						has_startup_experience, startup_experience, has_merger_acquisition_experience, merger_acquisition_experience, has_entrepenuer_experience, entrepenuer_experience, user_language_id_written_in, resume_origin_id, resume_origin_desc, etl_date, datasource_id)
						SELECT DISTINCT ON (resume_id) resume_id, database_context_id, has_pl_experience, largest_budget_answer_id, number_people_managed_answer_id, has_turn_arround_experience, trim(both ' ' from turnarround_experience), has_ipo_experience, trim(both ' ' from ipo_experience), has_startup_experience, trim(both ' ' from startup_experience), 
						has_merger_acquisition_experience, trim(both ' ' from merger_acquisition_experience), has_entrepenuer_experience, trim(both ' ' from entrepenuer_experience), user_language_id_written_in, resume_origin_id, resume_origin_desc, etl_date, datasource_id
						FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
						WHERE
							EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(03)_UserResumeDetails" RT1 WHERE ST.resume_id = RT1.resume_id)
							AND
							NOT EXISTS (SELECT 1 FROM "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT2 WHERE ST.resume_id = RT2.resume_id);
						GET DIAGNOSTICS cloud_resume_additional_infos_added = ROW_COUNT;
						
				RETURN QUERY SELECT cloud_users_inserted, ref_geo_id_inserted, cloud_user_addresses_inserted, cloud_user_resumes_inserted, cloud_resume_additional_infos_added, state_id_updates, channel_id_updates;
		END;

$$;
