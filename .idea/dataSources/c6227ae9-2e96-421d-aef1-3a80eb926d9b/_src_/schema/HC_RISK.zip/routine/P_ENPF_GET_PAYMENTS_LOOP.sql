CREATE procedure p_enpf_get_payments_loop(p_duration in integer)
  is
    v_dt date;
    v_dt1 date;
    v_iin varchar2(20);
    v_cn varchar2(100);
    n integer;
  begin
    execute immediate 'truncate table t_enpf_client_payments';

    select max(dt_load) into v_dt from main.working_date;
    v_dt1 := add_months(trunc(v_dt,'mm'),-nvl(p_duration,6));

    execute immediate 'truncate table tmp_i_mt102_dc2'; 
    n := 0;
    for rec in (select iin, contract_number from t_enpf_parameters_of_request)
    loop
      v_iin := rec.iin; v_cn := rec.contract_number;

      insert /*+ append */ into tmp_i_mt102_dc2
      (
         i_mt
        ,assign
        ,summ
        ,iin
        ,contract_number
      )
      select
         t2.i_mt
        ,t2.assign
        ,t2.summ
        ,v_iin
        ,v_cn
      from
        main.i_mt102_dc2 t2
      where
        t2.rnn = v_iin
      ;
      
      n := n+1;
      if mod(n,500) = 0 then commit; end if;
    end loop;

    commit;
    dbms_stats.gather_table_stats('HC_RISK','TMP_I_MT102_DC2');

    insert /*+ append */ into t_enpf_client_payments
    (
       contract_number
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    )
    select
       t2.contract_number
      ,t2.iin
      ,t3.work_date
      ,substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) as employer_name
      ,case
         when substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) is not null
         then substr(t2.assign,-12)
       end as employer_bin
      ,t2.summ
      ,t1.f70_pay_assign
      ,t1.reference
    from
           tmp_i_mt102_dc2 t2
      join (select a1.i_mt, a1.working_date, a1.f70_pay_assign, a1.reference from main.i_mt a1 where dt_load = v_dt) t1 on t1.i_mt = t2.i_mt
      join (select working_date, work_date from main.working_date where dt_load = v_dt and work_date >= v_dt1) t3 on t3.working_date = t1.working_date
    ;

    commit;

    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_CLIENT_PAYMENTS');
  end;
/
