create function "MediaBay"."SUBSCRIBER_USER_INSERT"() returns TABLE(subscriber_info_inserts integer, subscriber_account_details_inserts integer, subscriber_additional_infos_inserts integer, subscriber_subscription_details_inserts integer)
LANGUAGE plpgsql
AS $$
DECLARE
		subscriber_info_inserts integer;
		subscriber_account_details_inserts integer;
		subscriber_additional_infos_inserts integer;
		subscriber_subscription_details_inserts integer;
		BEGIN
			   --"MediaBay"."S_(01)_SubscriberInfoDetails"
			       INSERT INTO "MediaBay"."S_(01)_SubscriberInfoDetails" (subscriber_id, user_id, email_address, date_created, date_modified, etl_date, is_matched, matched_user_id, datasource_id, is_monster_user, email_address_status_id, is_trillium_matched)
                            SELECT DISTINCT ON (subscriber_id) subscriber_id, user_id, trim(both ' ' from email_address), date_created, date_modified, etl_date, is_matched, matched_user_id, datasource_id, is_monster_user, email_address_status_id, is_trillium_matched
                            FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails"
                            ON CONFLICT ON CONSTRAINT subscriber_info_pkey DO NOTHING;
					GET DIAGNOSTICS subscriber_info_inserts = ROW_COUNT;
			   --"MediaBay"."S_(02)_SubscriberAccountDetails"
				INSERT INTO "MediaBay"."S_(02)_SubscriberAccountDetails" (user_id, username, disabled, email_address, city, state_id, postal_code, country_id, confidential, date_created, channel_id, career_level_id, available_time_id, available_day, available_month,
				available_year, first_name, last_name, address1,address2, datetime_phone, evening_phone, mobile_phone, fax, pager, company, location_id, date_modified, date_deleted, middle_name, name_prefix_id, name_suffix, created_channel_id, us_zip5, etl_date, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, username, disabled, trim(both ' ' from email_address), initcap (trim(both ' ' from city)), state_id, trim(both ' ' from postal_code), country_id, confidential, date_created, channel_id, career_level_id, available_time_id, available_day, available_month,
				available_year, initcap (trim(both ' ' from first_name)), initcap (trim(both ' ' from last_name)), initcap (trim(both ' ' from address1)), initcap (trim(both ' ' from address2)), datetime_phone, evening_phone, mobile_phone, fax, pager, initcap (trim(both ' ' from company)), location_id, date_modified, date_deleted, initcap (trim(both ' ' from middle_name)), name_prefix_id, name_suffix, created_channel_id, us_zip5, etl_date, datasource_id
				FROM "MediaBay"."S_STG_(02)_SubscriberAccountDetails" ST
				ON CONFLICT DO NOTHING;
					GET DIAGNOSTICS subscriber_account_details_inserts = ROW_COUNT;
			   --"MediaBay"."S_(03)_SubscriberAdditionalInfo"
				INSERT INTO "MediaBay"."S_(03)_SubscriberAdditionalInfo" (subscriber_id, first_name, last_name, phone_number, postal_code, date_created, date_modified, etl_date, state_id, city, datasource_id)
				SELECT DISTINCT ON (subscriber_id) subscriber_id, initcap (trim(both ' ' from first_name)), initcap (trim(both ' ' from last_name)), trim(both ' ' from phone_number), trim(both ' ' from postal_code), date_created, date_modified, etl_date, state_id, initcap (trim(both ' ' from city)), datasource_id
				FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
				WHERE EXISTS (SELECT 1 FROM "MediaBay"."S_(01)_SubscriberInfoDetails" RT1 WHERE ST.subscriber_id = RT1.subscriber_id)
				AND NOT EXISTS (SELECT 1 FROM "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT2 WHERE ST.subscriber_id = RT2.subscriber_id);
					GET DIAGNOSTICS subscriber_additional_infos_inserts = ROW_COUNT;
			   --"MediaBay"."S_(05)_SubscriberSubscriptionDetails
			      ALTER TABLE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" DROP CONSTRAINT subscription_subscriber_id_fkey;
			      INSERT INTO "MediaBay"."S_(05)_SubscriberSubscriptionDetails" (subscription_id, subscriber_id, ip_address, subscription_action_id, object_type_id, link_id, created_date, etl_date, channel_id, datasource_id)
			      SELECT DISTINCT ON (subscription_id) subscription_id, subscriber_id, ip_address, subscription_action_id, object_type_id, link_id, created_date, etl_date, channel_id, datasource_id
			      FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			      ON CONFLICT DO NOTHING;
					GET DIAGNOSTICS subscriber_subscription_details_inserts = ROW_COUNT;
			      DELETE FROM "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."S_(01)_SubscriberInfoDetails" RT2 WHERE RT1.subscriber_id = RT2.subscriber_id);
                            ALTER TABLE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" ADD CONSTRAINT subscription_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES "MediaBay"."S_(01)_SubscriberInfoDetails" (subscriber_id) ON UPDATE CASCADE ON DELETE CASCADE;
				RETURN QUERY SELECT subscriber_info_inserts, subscriber_account_details_inserts, subscriber_additional_infos_inserts, subscriber_subscription_details_inserts;
		END;

$$;
