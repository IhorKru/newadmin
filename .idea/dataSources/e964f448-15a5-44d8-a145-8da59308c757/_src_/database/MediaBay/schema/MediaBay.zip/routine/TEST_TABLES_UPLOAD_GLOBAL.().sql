create function "MediaBay"."TEST_TABLES_UPLOAD_GLOBAL"() returns TABLE(cloud_user_info_details_uploaded integer)
LANGUAGE plpgsql
AS $$
DECLARE
		cloud_user_info_details_uploaded integer;
		BEGIN
				-- CLOUD JOBSEAKER USER TABLES UPLOAD
				--CLOUD_STG_(01)_UserInfoDetails info upload
				COPY "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(01)_USER.INFO.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--COPY "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(01)_USER.INFO.DETAILS_02.csv' DELIMITER ',' CSV HEADER;
				--COPY "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(01)_USER.INFO.DETAILS_03.csv' DELIMITER ',' CSV HEADER;
				--CLOUD_STG_(02)_UserAddressDetails
				COPY "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(02)_USER.ADDRESS.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--COPY "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(02)_USER.ADDRESS.DETAILS_02.csv' DELIMITER ',' CSV HEADER;
				--CLOUD_STG_(03)_UserResumeDetails
				COPY "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(03)_USER.RESUME.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--COPY "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(03)_USER.RESUME.DETAILS_02.csv' DELIMITER ',' CSV HEADER;
				--COPY "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(03)_USER.RESUME.DETAILS_03.csv' DELIMITER ',' CSV HEADER;
				--CLOUD_STG_(04)_UserResumeAdditionalinfo
				COPY "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(03.1)_USER.RESUME.ADDITIONAL.INFO.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."REF.STG.REF.GEO.DETAILS"
				COPY "MediaBay"."REF.STG.REF.GEO.DETAILS" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(JS.U.03.01)_REF.JS.USER.REF.GEO(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."REF.STG.USER.CHANNEL.DETAILS"
				COPY "MediaBay"."REF.STG.USER.CHANNEL.DETAILS" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/cloud_js_user/(JS.U.01.5)_JS.USER.CHANNEL.DETAILS.csv' DELIMITER ',' CSV HEADER;
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@invalidmail.com';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@nomail.com';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@nomail.act1.com';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@Site.careerbuilde';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@Site.MiracleWorke';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@users.monster.com';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@example.com';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@careeronecdn.com.au';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@reply%';
				DELETE FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" WHERE email_address LIKE '%@Site.CareerBuilder-Jobs.com%';

				--JOBSEAKER USER TABLE UPLOAD
				--"MediaBay"."JS_U_STG_(01)_UserInfoDetails"
				COPY "MediaBay"."JS_U_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01)_JS.USER.INFO.DETAILS(BI)_01.csv' DELIMITER ',' CSV HEADER;
				COPY "MediaBay"."JS_U_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01)_JS.USER.INFO.DETAILS(BI)_02.csv' DELIMITER ',' CSV HEADER;
				COPY "MediaBay"."JS_U_STG_(01)_UserInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01)_JS.USER.INFO.DETAILS(BI)_03.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(01.1)_UserEmailStatus"
				COPY "MediaBay"."JS_U_STG_(01.1)_UserEmailStatus" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01.1)_JS.USER.EMAIL.STATUS.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo"
				COPY "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01.2)_JS.USER.ADDITIONAL.INFO.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo"
				COPY "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01.3)_JS.USER.OPTIONAL.INFO.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_(01.4)_UserLegalStatus"
				COPY "MediaBay"."JS_U_STG_(01.4)_UserLegalStatus" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01.4)_JS.USER.LEGAL.STATUS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(01.5)_UserWorkStatus"
				COPY "MediaBay"."JS_U_STG_(01.5)_UserWorkStatus" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.01.6).JS.USER.WORK.STATUS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(02)_UserPhoneDetails"
				COPY "MediaBay"."JS_U_STG_(02)_UserPhoneDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.02)_JS.USER.PHONE.DETAILS(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_(03)_UserAddressDetails"
				COPY "MediaBay"."JS_U_STG_(03)_UserAddressDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.03)_JS.USER.ADDRESS.DETAILS(BI).csv' DELIMITER ',' CSV HEADER;
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address1 = NULL WHERE address1 = 'rmpurge';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address1 = NULL WHERE address1 = 'rmvdaur';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address2 = NULL WHERE address2 = 'rmpurge';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address2 = NULL WHERE address2 = 'rmvdaur';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address1 = NULL WHERE address1 = '0';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address2 = NULL WHERE address2 = '0';
				--"MediaBay"."JS_U_STG_(04)_UserLanguageDetails"
				COPY "MediaBay"."JS_U_STG_(04)_UserLanguageDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.04)_JS.USER.LANGUAGE.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."REF.STG.USER.REF.SCHOOL.DETAILS"
				COPY "MediaBay"."REF.STG.USER.REF.SCHOOL.DETAILS" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.05.1)_JS.USER.SCHOOL.DETAILS(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(05)_UserEducationDetails"
				 COPY "MediaBay"."JS_U_STG_(05)_UserEducationDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.05)_JS.USER.EDUCATION.DETAILS(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."REF.JS.USER.REF.FIELD.OF.STUDY"
                              COPY "MediaBay"."REF.STG.REF.FIELD.OF.STUDY" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.05.2.1)_REF.JS.USER.EDUCATION.FIELD.DEAILS(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(05.1)_UserEducationField"
				  COPY "MediaBay"."JS_U_STG_(05.1)_UserEducationField" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.05.2)_JS.USER.EDUCATION.FIELD(BI).csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."JS_U_STG_(20)_UserLoginDetails"
				  COPY "MediaBay"."JS_U_STG_(20)_UserLoginDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(01)_USER_DATA/js_user/(JS.U.20)_JS.USER.LOGIN.DETAILS.csv' DELIMITER ',' CSV HEADER;

				--PUBLISHER TEST TABLE UPLOADS
				--"MediaBay"."P_STG_(01)_PublisherDetails"
				COPY "MediaBay"."P_STG_(01)_PublisherDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(03)_PUBLISHER/(P.01)_PUBLISHER.ACCOUNT.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."P_STG_(02)_PublisherSiteDetails"
				COPY "MediaBay"."P_STG_(02)_PublisherSiteDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(03)_PUBLISHER/(P.02)_PUBLISHER.SITE.DETAILS.csv' DELIMITER ',' CSV HEADER;

				--RECRUITER TEST TABLE UPLOADS
				--"MediaBay"."R_STG_(01)_RecruiterDetails"
				COPY "MediaBay"."R_STG_(01)_RecruiterDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.01)_ACC.RECRUITER.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(01.1)_RecruiterAdditionalInfo"
				COPY "MediaBay"."R_STG_(01.1)_RecruiterAdditionalInfo" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.01.1)_ACC.RECRUITER.ADDITIONAL.INFO.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(01.2)_RecruiterLoginDetails"
				--COPY "MediaBay"."R_STG_(01.2)_RecruiterLoginDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.01.2)_ACC.RECRUITER.LOGIN.INFO.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails"
				COPY "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.03)_ESHOPPING.CART.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser"
				COPY "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.03.1)_RECRUITER.ESHOPPING.CART.USER.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact"
				COPY "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.03.2)_SHOPPING.CART.CONTACT.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"
				COPY "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.03.3)_SHOPPING.CART.BILLING.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart"
				COPY "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" FROM '/Volumes/MEDIABAY(W)/db_upload/(04)_RECRUITER/(R.03.4)_ACC.ABANDONED.ESHOPPING.CART.csv' DELIMITER ',' CSV HEADER;
					UPDATE "MediaBay"."R_STG_(01)_RecruiterDetails" SET middle_name = NULL WHERE middle_name = 'rmpurge';
					UPDATE "MediaBay"."R_STG_(01)_RecruiterDetails" SET first_name = NULL WHERE first_name = 'rmpurge';
					UPDATE "MediaBay"."R_STG_(01)_RecruiterDetails" SET last_name = NULL WHERE last_name = 'rmpurge';
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address IS NULL;
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%monster%');
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%noreply%');
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%@nowhere.com%');
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%@helloworld.com%');
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%@test%');
					DELETE FROM "MediaBay"."R_STG_(01)_RecruiterDetails" WHERE email_address LIKE ('%0@%');
				
				--SUBSCRIBER TEST TABLE UPLOADS
				--"MediaBay"."S_STG_(01)_SubscriberInfoDetails"
				COPY "MediaBay"."S_STG_(01)_SubscriberInfoDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(02)_SUBSCRIBER/(S.01)_SUBSCRIBER.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."S_STG_(02)_SubscriberAccountDetails"
				COPY "MediaBay"."S_STG_(02)_SubscriberAccountDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(02)_SUBSCRIBER/(S.02)_SUBSCRIBER.ACCOUNT.DETAILS.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."S_STG_(03)_SubscriberAdditionalInfo"
				COPY "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" FROM '/Volumes/MEDIABAY(W)/db_upload/(02)_SUBSCRIBER/(S.03)_SUBSCRIBER.ADDITIONAL.INFO.csv' DELIMITER ',' CSV HEADER;
				--"MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails"
				COPY "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" FROM '/Volumes/MEDIABAY(W)/db_upload/(02)_SUBSCRIBER/(S.05)_SUBSCRIBER.SUBSCRIPTION.DETAILS.csv' DELIMITER ',' CSV HEADER;
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@invalidmail.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@nomail.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@nomail.act1.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@Site.careerbuilde';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@Site.MiracleWorke';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@users.monster.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@example.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@careeronecdn.com.au';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@reply%';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@Site.CareerBuilder-Jobs.com%';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%@selenium.monster.com';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address LIKE '%spam%';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address IS NULL;
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address ILIKE '%QA_PAT%';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address ILIKE '%@monster%';
					DELETE FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" WHERE email_address ILIKE '%PAT_TEST%';
					UPDATE "MediaBay"."S_STG_(01)_SubscriberInfoDetails" SET email_address = REPLACE(email_address,'%40','@') WHERE email_address LIKE ('%&undefined&undefined&undefined');
					UPDATE "MediaBay"."S_STG_(01)_SubscriberInfoDetails" SET email_address = REPLACE(email_address,'&undefined&undefined&undefined','');
					DELETE FROM "MediaBay"."S_(01)_SubscriberInfoDetails" WHERE email_address ilike ('%_EmailNotProvided_%') AND email_address ilike ('%@ohiomeansjobs%');

				RETURN QUERY SELECT cloud_user_info_details_uploaded;
		END;

$$;
