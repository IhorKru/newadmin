create function "MediaBay"."PUBLISHER_USER_DATA_INSERT"() returns TABLE(publisher_info_inserted integer, publisher_site_info_inserted integer, publisher_site_category_inserts integer)
LANGUAGE plpgsql
AS $$
DECLARE
		publisher_info_inserted integer;
		publisher_site_info_inserted integer;
		publisher_site_category_inserts integer;
		BEGIN
				--"MediaBay"."P_(01)_PublisherDetails"
				INSERT INTO "MediaBay"."P_(01)_PublisherDetails" (pubisher_id, user_id, publisher_guid, publisher_name, commission_junction_pid, date_modified, date_created, etl_date, publisher_email_address, datasource_id, job_view_domain_channel_id, cj_validated, cjpid)
				SELECT DISTINCT ON (pubisher_id) pubisher_id, user_id, publisher_guid, publisher_name, commission_junction_pid, date_modified, date_created, etl_date, publisher_email_address, datasource_id, job_view_domain_channel_id, cj_validated, cjpid
				FROM "MediaBay"."P_STG_(01)_PublisherDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS publisher_info_inserted = ROW_COUNT;
				--"MediaBay"."P_(02)_PublisherSiteDetails"
				DELETE FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST where not exists (select 1 from "MediaBay"."P_(01)_PublisherDetails" RT where ST.publisher_id = RT.pubisher_id);
				INSERT INTO "MediaBay"."P_(02)_PublisherSiteDetails" (publisher_site_id, publisher_id, publisher_site_url, publisher_site_desc, publisher_site_status_id, site_volume_id, date_modified, date_created, etl_date, datasource_id, cjpid)
				SELECT DISTINCT ON (publisher_site_id) publisher_site_id, publisher_id, publisher_site_url, publisher_site_desc, publisher_site_status_id, site_volume_id, date_modified, date_created, etl_date, datasource_id, cjpid
				FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS publisher_site_info_inserted = ROW_COUNT;
				--"MediaBay"."P_(03)_PublisherSiteCategory"
				DELETE FROM "MediaBay"."P_STG_(03)_PublisherSiteCategory" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."P_(02)_PublisherSiteDetails" RT WHERE ST.publisher_site_id = RT.publisher_site_id);
				INSERT INTO "MediaBay"."P_(03)_PublisherSiteCategory" (publisher_site_category_id, job_category_id, publisher_site_id, date_modified, date_created, etl_date, datasource_id)
				SELECT DISTINCT ON (publisher_site_category_id) publisher_site_category_id, job_category_id, publisher_site_id, date_modified, date_created, etl_date, datasource_id
				FROM "MediaBay"."P_STG_(03)_PublisherSiteCategory"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS publisher_site_category_inserts = ROW_COUNT;
				RETURN QUERY SELECT publisher_info_inserted, publisher_site_info_inserted, publisher_site_category_inserts;
		END;

$$;
