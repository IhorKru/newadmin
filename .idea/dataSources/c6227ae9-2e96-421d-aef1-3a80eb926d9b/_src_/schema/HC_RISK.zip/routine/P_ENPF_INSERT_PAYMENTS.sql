CREATE procedure p_enpf_insert_payments(p_id_request in integer, p_duration in integer)
  is
    v_id_request integer;
  begin
    v_id_request := p_id_request;

    p_enpf_gather_stats('T_ENPF_PARAMETERS_OF_REQUEST');
    p_enpf_get_payments_loop(p_duration);

    insert into r_algoritm.t_enpf_client_payments@dti
    (
       id_request
      ,contract_number
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    )
    select
       v_id_request
      ,contract_number
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    from
      t_enpf_client_payments;

    commit;
  end;
/
