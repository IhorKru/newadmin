CREATE procedure p_enpf_truncate_table(p_table_name varchar2)
  is
  begin
    execute immediate 'truncate table '||p_table_name;
  end;
/
