CREATE procedure p_enpf_get_payments(p_duration in integer)
  is
    v_dt date;
    v_dt1 date;
  begin
    execute immediate 'truncate table t_enpf_client_payments';

    select max(dt_load) into v_dt from main.working_date;
    v_dt1 := add_months(trunc(v_dt,'mm'),-nvl(p_duration,6));

    insert /*+ append */ into t_enpf_client_payments
    (
       contract_number
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    )
    select
       t4.contract_number
      ,t4.iin
      ,t3.work_date
      ,substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) as employer_name
      ,case
         when substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) is not null
         then substr(t2.assign,-12)
       end as employer_bin
      ,t2.summ
      ,t1.f70_pay_assign
      ,t1.reference
    from
           t_enpf_parameters_of_request t4
      join main.i_mt102_dc2 t2 on t2.rnn = t4.iin
      join (select a1.i_mt, a1.working_date, a1.f70_pay_assign, a1.reference from main.i_mt a1 where dt_load = v_dt) t1 on t1.i_mt = t2.i_mt
      join (select working_date, work_date from main.working_date where dt_load = v_dt and work_date >= v_dt1) t3 on t3.working_date = t1.working_date
    ;

    commit;

    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_CLIENT_PAYMENTS');
  end;
/
