create function "MediaBay"."CLOUD_USER_UPDATE"() returns TABLE(name_prefix_id_updated integer, first_name_updated integer, middle_name_updated integer, lastname_updated integer, name_sufix_updated integer, country_id_updated integer, state_id_updated integer, cities_updated integer, address1_updates integer, address2_updates integer, postal_code_updates integer, us_zip5_updates integer, location_id_updates integer, confidential_updates integer, disabled_updates integer, channel_id_updates integer, career_level_id_updates integer, available_time_id_updates integer, available_day_updates integer, available_month_updates integer, available_year_updates integer, daytime_phone_updates integer, evening_phone_updates integer, mobile_phone_updates integer, fax_updates integer, pager_updates integer, company_updates integer, date_modified_updates integer, date_deleted_updates integer, etl_date_updates integer, created_channel_id_updates integer, ad_address_type_id_updates integer, ad_verified_id_updates integer, ad_address1_updates integer, ad_address2_updates integer, ad_city_updates integer, ad_postal_code_updates integer, ad_ref_geo_id_updates integer, ad_preferred_method_updates integer, ad_modified_date_updates integer)
LANGUAGE plpgsql
AS $$
DECLARE
	-- CLOUD USER VARIABLES
	name_prefix_id_updated integer; first_name_updated integer; middle_name_updated integer; lastname_updated integer; name_sufix_updated integer; country_id_updated integer; state_id_updated integer; cities_updated integer; address1_updates integer; address2_updates integer; postal_code_updates integer;
	us_zip5_updates integer; location_id_updates integer; confidential_updates integer; disabled_updates integer; channel_id_updates integer; career_level_id_updates integer; available_time_id_updates integer; available_day_updates integer; available_month_updates integer; available_year_updates integer;
	daytime_phone_updates integer; evening_phone_updates integer; mobile_phone_updates integer; fax_updates integer; pager_updates integer; company_updates integer; date_modified_updates integer; date_deleted_updates integer;  etl_date_updates integer; created_channel_id_updates integer;
	--ADDRESS VARIABLES
	ad_address_type_id_updates integer; ad_verified_id_updates integer; ad_address1_updates integer; ad_address2_updates integer; ad_city_updates integer; ad_postal_code_updates integer; ad_ref_geo_id_updates integer; ad_preferred_method_updates integer; ad_modified_date_updates integer;
	BEGIN
			--NAME PREFIX ID UPDATE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT 
					SET name_prefix_id = ST.name_prefix_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND ST.name_prefix_id <> RT.name_prefix_id
					AND ST.name_prefix_id IS NOT NULL
					AND ST.name_prefix_id <> 0;
					GET DIAGNOSTICS name_prefix_id_updated = ROW_COUNT;
			--FIRST NAME UPDATE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.first_name <> initcap(trim(both ' ' from ST.first_name))
					AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.first_name)) <> '0';
					GET DIAGNOSTICS first_name_updated = ROW_COUNT;
			--MIDDLE NAME UPDATE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET middle_name = initcap(trim(both ' ' from ST.middle_name))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.middle_name <> initcap(trim(both ' ' from ST.middle_name))
					AND initcap(trim(both ' ' from ST.middle_name)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.middle_name)) <> '0';
					GET DIAGNOSTICS middle_name_updated = ROW_COUNT;
			--LAST NAME UPDATE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET last_name = initcap(trim(both ' ' from ST.last_name))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.last_name <> initcap(trim(both ' ' from ST.last_name))
					AND LENGTH(ST.last_name) > LENGTH(RT.last_name);
					GET DIAGNOSTICS lastname_updated = ROW_COUNT;
			--NAME SUFIX
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET name_suffix = trim(both ' ' from ST.name_suffix)
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.name_suffix <> trim(both ' ' from ST.name_suffix)
					AND ST.name_suffix <> '0'
					AND ST.name_suffix IS NOT NULL;
					GET DIAGNOSTICS name_sufix_updated = ROW_COUNT;
			--COUNTRY ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET country_id = ST.country_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.country_id <> ST.country_id
					AND ST.country_id <> '0'
					AND ST.country_id IS NOT NULL;
					GET DIAGNOSTICS country_id_updated = ROW_COUNT;
			--STATE ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET state_id = ST.state_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.state_id <> ST.state_id
					AND ST.state_id <> '0'
					AND ST.state_id IS NOT NULL;
					GET DIAGNOSTICS state_id_updated = ROW_COUNT;
			--CITY
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET city = initcap(trim(both ' ' from ST.city))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.city <> initcap(trim(both ' ' from ST.city))
					AND initcap(trim(both ' ' from ST.city)) <> '0'
					AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
					GET DIAGNOSTICS cities_updated = ROW_COUNT;
			--ADDRESS1
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET address1 = initcap(trim(both ' ' from ST.address1))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.address1 <> initcap(trim(both ' ' from ST.address1))
					AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.address1)) <> '0';
					GET DIAGNOSTICS address1_updates = ROW_COUNT;
			--ADDRESS2
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET address2 = initcap(trim(both ' ' from ST.address2))
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.address2 <> initcap(trim(both ' ' from ST.address2))
					AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.address2)) <> '0';
					GET DIAGNOSTICS address2_updates = ROW_COUNT;
			--POSTAL CODE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET postal_code = trim(both ' ' from ST.postal_code)
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.postal_code <> trim(both ' ' from ST.postal_code)
					AND initcap(trim(both ' ' from ST.postal_code)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.postal_code)) <> '0';
					GET DIAGNOSTICS postal_code_updates = ROW_COUNT;
			--US ZIP CODE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET us_zip5 = trim(both ' ' from ST.us_zip5)
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.us_zip5 <> trim(both ' ' from ST.us_zip5)
					AND initcap(trim(both ' ' from ST.us_zip5)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.us_zip5)) <> '0';
					GET DIAGNOSTICS us_zip5_updates = ROW_COUNT;
			--LOCATION ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET location_id = ST.location_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.location_id <> ST.location_id
					AND ST.location_id <> '0'
					AND ST.location_id IS NOT NULL;
					GET DIAGNOSTICS location_id_updates = ROW_COUNT;
			--CONFIDENTIAL
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET confidential = ST.confidential
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.confidential <> ST.confidential;
					GET DIAGNOSTICS confidential_updates = ROW_COUNT;
			--DISABLED
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET disabled = ST.disabled
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.disabled <> ST.disabled;
					GET DIAGNOSTICS disabled_updates = ROW_COUNT;
			--CHANNEL_ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET channel_id = ST.channel_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.channel_id <> ST.channel_id
					AND ST.channel_id IS NOT NULL
					AND ST.channel_id <> 0;
					GET DIAGNOSTICS channel_id_updates = ROW_COUNT;
			--CAREER LEVEL ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET career_level_id = ST.career_level_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.career_level_id <> ST.career_level_id
					AND ST.career_level_id IS NOT NULL
					AND ST.career_level_id <> 0;
					GET DIAGNOSTICS career_level_id_updates = ROW_COUNT;
			--AVAILALBE TIME ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET available_time_id = ST.available_time_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.available_time_id <> ST.available_time_id
					AND ST.available_time_id IS NOT NULL
					AND ST.available_time_id <> 0;
					GET DIAGNOSTICS available_time_id_updates = ROW_COUNT;
			--AVAILALBE DAY
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET available_day = ST.available_day
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.available_day <> ST.available_day
					AND ST.available_day IS NOT NULL
					AND ST.available_day <> 0;
					GET DIAGNOSTICS available_day_updates = ROW_COUNT;
			--AVAILALBE MONTH
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET available_month = ST.available_month
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.available_month <> ST.available_month
					AND ST.available_month IS NOT NULL
					AND ST.available_month <> 0;
					GET DIAGNOSTICS available_month_updates = ROW_COUNT;
			--AVAILALBE YEAR
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET available_year = ST.available_year
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.available_year <> ST.available_year
					AND ST.available_year IS NOT NULL
					AND ST.available_year <> 0;
					GET DIAGNOSTICS available_year_updates = ROW_COUNT;
			--DAYTIME PHONE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET daytime_phone = ST.daytime_phone
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.daytime_phone <> ST.daytime_phone
					AND ST.daytime_phone IS NOT NULL
					AND ST.daytime_phone <> '0';
					GET DIAGNOSTICS daytime_phone_updates = ROW_COUNT;
			--EVENING PHONE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET evening_phone = ST.evening_phone
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.evening_phone <> ST.evening_phone
					AND ST.evening_phone IS NOT NULL
					AND ST.evening_phone <> '0';
					GET DIAGNOSTICS evening_phone_updates = ROW_COUNT;
			--MOBILE PHONE
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET mobile_phone = ST.mobile_phone
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.mobile_phone <> ST.mobile_phone
					AND ST.mobile_phone IS NOT NULL
					AND ST.mobile_phone <> '0';
					GET DIAGNOSTICS mobile_phone_updates = ROW_COUNT;
			--FAX
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET fax = ST.fax
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.fax <> ST.fax
					AND ST.fax IS NOT NULL
					AND ST.fax <> '0';
					GET DIAGNOSTICS fax_updates = ROW_COUNT;
			--PAGER
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET pager = ST.pager
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.pager <> ST.pager
					AND ST.pager IS NOT NULL
					AND ST.pager <> '0';
					GET DIAGNOSTICS pager_updates = ROW_COUNT;
			--COMPANY
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET company = trim(both ' ' from ST.company)
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE	
					RT.user_id = ST.user_id
					AND RT.company <> trim(both ' ' from ST.company)
					AND trim(both ' ' from ST.company) IS NOT NULL
					AND trim(both ' ' from ST.company) <> '0';
					GET DIAGNOSTICS company_updates = ROW_COUNT;
			--DATE MODIFIED
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET date_modified = ST.date_modified
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.date_modified < ST.date_modified
					AND ST.date_modified IS NOT NULL;
					GET DIAGNOSTICS date_modified_updates = ROW_COUNT;
			--DATE DELETED
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET date_deleted = ST.date_deleted
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.date_deleted <> ST.date_deleted
					AND ST.date_deleted IS NOT NULL;
					GET DIAGNOSTICS date_deleted_updates = ROW_COUNT;
			--ETL DELETED
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET etl_date = ST.etl_date
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.etl_date <> ST.etl_date
					AND ST.etl_date IS NOT NULL;
					GET DIAGNOSTICS etl_date_updates = ROW_COUNT;
			--CREATED CHANNEL ID
			UPDATE "MediaBay"."CLOUD_(01)_UserInfoDetails" RT
					SET created_channel_id= ST.created_channel_id
			FROM "MediaBay"."CLOUD_STG_(01)_UserInfoDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.created_channel_id <> ST.created_channel_id
					AND ST.created_channel_id IS NOT NULL
					AND ST.created_channel_id <> 0;
					GET DIAGNOSTICS created_channel_id_updates = ROW_COUNT;
			--ADDRESS_ADDRESS TYPE ID UPDATE
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET address_type_id = ST.address_type_id
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND ST.address_type_id <> RT.address_type_id
					AND ST.address_type_id <> 0
					AND ST.address_type_id IS NOT NULL;
					GET DIAGNOSTICS ad_address_type_id_updates = ROW_COUNT;
			--ADDRESS_VERIFIED ID UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET verified_id = ST.verified_id
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND ST.verified_id <> RT.verified_id
					AND ST.verified_id <> '0'
					AND ST.verified_id IS NOT NULL;
					GET DIAGNOSTICS ad_verified_id_updates = ROW_COUNT;
			--ADDRESS_ADDRESS1 UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET address1 = initcap(trim(both ' ' from ST.address1))
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.address1 <> initcap(trim(both ' ' from ST.address1))
					AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.address1)) <> '0';
					GET DIAGNOSTICS ad_address1_updates = ROW_COUNT;
			--ADDRESS_ADDRESS2 UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET address2 = initcap(trim(both ' ' from ST.address2))
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.address2 <> initcap(trim(both ' ' from ST.address2))
					AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.address2)) <> '0';
					GET DIAGNOSTICS ad_address2_updates = ROW_COUNT;
			--ADDRESS_CITY UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET city =  initcap(trim(both ' ' from ST.city))
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.city <> initcap(trim(both ' ' from ST.city))
					AND initcap(trim(both ' ' from ST.city)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.city)) <> '0';
					GET DIAGNOSTICS ad_city_updates = ROW_COUNT;
			--ADDRESS_POSTAL CODE UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET postal_code =  trim(both ' ' from ST.postal_code)
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.postal_code <> trim(both ' ' from ST.postal_code)
					AND trim(both ' ' from ST.postal_code) IS NOT NULL
					AND trim(both ' ' from ST.postal_code) <> '0';
					GET DIAGNOSTICS ad_postal_code_updates = ROW_COUNT;
			--ADDRESS_REF GEO ID UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET ref_geo_id =  ST.ref_geo_id
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.ref_geo_id <> ST.ref_geo_id
					AND ST.ref_geo_id IS NOT NULL
					AND ST.ref_geo_id <> '0';
					GET DIAGNOSTICS ad_ref_geo_id_updates = ROW_COUNT;
			--ADDRESS_PREFERED METHOD UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET preferred_method =  ST.preferred_method
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.preferred_method <> ST.preferred_method
					AND ST.preferred_method IS NOT NULL;
					GET DIAGNOSTICS ad_preferred_method_updates = ROW_COUNT;
			--ADDRESS_MODIFIED DATE UPDATES
			UPDATE "MediaBay"."CLOUD_(02)_UserAddressDetails" RT 
					SET modified_date =  ST.modified_date
			FROM "MediaBay"."CLOUD_STG_(02)_UserAddressDetails" ST
			WHERE
					RT.user_id = ST.user_id
					AND RT.modified_date <> ST.modified_date
					AND ST.modified_date IS NOT NULL;
					GET DIAGNOSTICS ad_modified_date_updates = ROW_COUNT;
			--GET RESULTS IN THE QUERY
			RETURN QUERY SELECT name_prefix_id_updated, first_name_updated, middle_name_updated, lastname_updated, name_sufix_updated, country_id_updated, state_id_updated, cities_updated, address1_updates, address2_updates, postal_code_updates,
			us_zip5_updates, location_id_updates, confidential_updates, disabled_updates, channel_id_updates, career_level_id_updates, available_time_id_updates, available_day_updates, available_month_updates, available_year_updates,
			daytime_phone_updates, evening_phone_updates, mobile_phone_updates, fax_updates, pager_updates, company_updates, date_modified_updates, date_deleted_updates, etl_date_updates, created_channel_id_updates,
			--ADDRESS VARIABLES
			ad_address_type_id_updates, ad_verified_id_updates, ad_address1_updates, ad_address2_updates, ad_city_updates, ad_postal_code_updates, ad_ref_geo_id_updates, ad_preferred_method_updates, ad_modified_date_updates;
	END;
$$;
