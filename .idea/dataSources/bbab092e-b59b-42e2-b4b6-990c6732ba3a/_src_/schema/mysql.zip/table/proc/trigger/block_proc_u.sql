CREATE TRIGGER `block_proc_u`
BEFORE UPDATE ON `proc`
FOR EACH ROW
  BEGIN
DECLARE foo varchar(255);
if old.Definer = "rdsadmin@localhost" then
  select `ERROR (RDS): CANNOT MODIFY RDSDMIN OBJECT` into foo;
end if;
END