CREATE procedure p_enpf_insert_client_data(p_id_request in integer, p_iin varchar2, p_duration integer)
  is
    v_dt  date;
    v_dt1 date;
  begin
    select max(dt_load) into v_dt from main.working_date;
    v_dt1 := add_months(trunc(v_dt,'mm'),-nvl(p_duration,12));

    delete from t_enpf_client_contacts_ce where id_request = p_id_request;
    delete from t_enpf_client_payments_ce where id_request = p_id_request;
    commit;

    insert into t_enpf_client_contacts_ce
    (
       id_request
      ,iin
      ,phone_work
      ,phone_home
      ,phone_mobile
      ,address_registration
    )
    select
       p_id_request
      ,p_iin
      ,np.phone_work
      ,np.phone
      ,np.phone_mobile
      ,
      nvl(
          np.address,
          nvl(np.adress_post_index, np.pind)||', '||r.name||', '||d.name||', '||gc.name||', '||
          np.adress_street||', дом '||np.adress_house_num||', кв. '||np.adress_flat_num
         )
    from
                (select * from main.g_nat_person_dc2 where idn = p_iin) np
      left join main.g_district d on d.g_district = np.adress_g_district and d.dt_load = v_dt
      left join main.g_region r on r.g_region = d.g_region and r.dt_load = v_dt
      left join main.g_city gc on gc.g_city = np.adress_g_city and gc.dt_load = v_dt
    ;

    commit;

    insert into t_enpf_client_payments_ce
    (
       id_request
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    )
    select
       p_id_request
      ,p_iin
      ,t3.work_date
      ,substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) as employer_name
      ,case
         when substr(t2.assign,instr(t2.assign,'/',1,2)+1,instr(t2.assign,'/',1,3)-instr(t2.assign,'/',1,2)-1) is not null
         then substr(t2.assign,-12)
       end as employer_bin
      ,t2.summ
      ,t1.f70_pay_assign
      ,t1.reference
    from
           (select * from main.i_mt102_dc2 where rnn = p_iin) t2
      join (select a1.i_mt, a1.working_date, a1.f70_pay_assign, a1.reference from main.i_mt a1 where dt_load = v_dt) t1 on t1.i_mt = t2.i_mt
      join (select working_date, work_date from main.working_date where dt_load = v_dt and work_date >= v_dt1) t3 on t3.working_date = t1.working_date
    ;

    commit;

    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_CLIENT_CONTACTS_CE');
    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_CLIENT_PAYMENTS_CE');

    insert into r_algoritm.t_enpf_client_contacts@dti
    (
       id_request
      ,iin
      ,phone_work
      ,phone_home
      ,phone_mobile
      ,address_registration
    )
    select
       id_request
      ,iin
      ,phone_work
      ,phone_home
      ,phone_mobile
      ,address_registration
    from
      t_enpf_client_contacts_ce
    where
      id_request = p_id_request;

    insert into r_algoritm.t_enpf_client_payments@dti
    (
       id_request
      ,contract_number
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    )
    select
       id_request
      ,null
      ,iin
      ,date_transfer
      ,employer_name
      ,employer_bin
      ,amount
      ,comments
      ,mt_number
    from
      t_enpf_client_payments_ce
    where
      id_request = p_id_request;

    commit;

  end;
/
