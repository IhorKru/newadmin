create function "MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() returns TABLE(jobseaker_user_info_name_prefix_id_updates integer, jobseaker_user_info_first_name_updates integer, jobseaker_user_info_middle_name_updates integer, jobseaker_user_info_last_name_updates integer, jobseaker_user_info_name_suffix_updates integer, jobseaker_user_info_email_address_updates integer, jobseaker_user_info_country_id_updates integer, jobseaker_user_info_state_id_updates integer, jobseaker_user_info_us_zip5_updates integer, jobseaker_user_info_location_id_updates integer, jobseaker_user_info_confidential_updates integer, jobseaker_user_info_disabled_updates integer, jobseaker_user_info_channel_id_updates integer, jobseaker_user_info_career_level_id_updates integer, jobseaker_user_info_available_time_id_updates integer, jobseaker_user_info_available_day_updates integer, jobseaker_user_info_available_month_updates integer, jobseaker_user_info_available_year_updates integer, jobseaker_user_info_company_updates integer, jobseaker_user_info_date_modified_updates integer, jobseaker_user_info_date_deleted_updates integer, jobseaker_user_info_etl_date_updates integer, jobseaker_user_info_created_channel_id_updates integer, jobseaker_user_contact_prefered_format_id_updates integer, jobseaker_user_year_experience_id_updates integer, jobseaker_user_us_military_involvement_id_updates integer, jobseaker_user_date_modified_updates integer, jobseaker_user_years_user_exp_id_project_leadership_updates integer, jobseaker_user_year_user_exp_id_management_updates integer, jobseaker_user_local_location_id_updates integer, jobseaker_user_datasource_id_updates integer, user_opional_info_country_id_updates integer, user_opional_info_dob_day_updates integer, user_opional_info_dob_month_updates integer, user_opional_info_dob_year_updates integer, user_opional_info_gender_id_updates integer, user_opional_info_ethnicity_id_updates integer, user_opional_info_date_modified_updates integer, user_opional_info_purged_updates integer, user_opional_info_disability_updates integer, user_opional_info_disability_desc_updates integer, user_opional_info_ex_convict_updates integer, user_opional_info_vectim_of_terrorism_updates integer, user_opional_info_employment_equity_candidate_updates integer, user_opional_info_new_customer_update integer, user_opional_info_target_product_type_id_updates integer, user_opional_info_karma_company_size_id_updates integer, user_opional_info_copmany_group_id_updates integer, user_opional_info_datasource_id_updates integer, user_ref_school_details_inserts integer, user_education_education_level_id_updates integer, user_education_ref_school_id_updates integer, user_education_start_month_updates integer, user_education_start_year_updates integer, user_education_completed_day_updates integer, user_education_completed_month_updates integer, user_education_completed_year_updates integer, user_education_education_subject_updates integer, user_education_education_summary_updates integer, user_education_gpa_updates integer, user_education_city_updates integer, user_education_state_updates integer, user_education_country_id_updates integer, user_education_resume_education_id_updates integer, user_education_resume_id_updates integer, user_education_date_modified_updates integer, user_education_date_deleted_updates integer, user_education_etl_date_updates integer, user_ref_education_field_inserted integer, user_education_field_inserted integer)
LANGUAGE plpgsql
AS $$
DECLARE
			  --"MediaBay"."JS_U_(01)_UserInfoDetails"
			  jobseaker_user_info_name_prefix_id_updates integer; jobseaker_user_info_first_name_updates integer; jobseaker_user_info_middle_name_updates integer; jobseaker_user_info_last_name_updates integer; jobseaker_user_info_name_suffix_updates integer; 
			  jobseaker_user_info_email_address_updates integer; jobseaker_user_info_country_id_updates integer; jobseaker_user_info_state_id_updates integer; jobseaker_user_info_us_zip5_updates integer; jobseaker_user_info_location_id_updates integer;
			  jobseaker_user_info_confidential_updates integer; jobseaker_user_info_disabled_updates integer; jobseaker_user_info_channel_id_updates integer; jobseaker_user_info_career_level_id_updates integer; jobseaker_user_info_available_time_id_updates integer; jobseaker_user_info_available_day_updates integer; 
			  jobseaker_user_info_available_month_updates integer; jobseaker_user_info_available_year_updates integer; jobseaker_user_info_company_updates integer; jobseaker_user_info_date_modified_updates integer; jobseaker_user_info_date_deleted_updates integer; jobseaker_user_info_etl_date_updates integer; 
			  jobseaker_user_info_created_channel_id_updates integer;
			  --"MediaBay"."JS_U_(01.2)_UserAdditionalInfo"
			  jobseaker_user_contact_prefered_format_id_updates integer; jobseaker_user_year_experience_id_updates integer; jobseaker_user_us_military_involvement_id_updates integer; jobseaker_user_date_modified_updates integer; jobseaker_user_years_user_exp_id_project_leadership_updates integer; 
			  jobseaker_user_year_user_exp_id_management_updates integer; jobseaker_user_local_location_id_updates integer; jobseaker_user_datasource_id_updates integer;
			  --"MediaBay"."JS_U_(01.3)_UserOptionalInfo"
			  user_opional_info_country_id_updates integer; user_opional_info_dob_day_updates integer; user_opional_info_dob_month_updates integer; user_opional_info_dob_year_updates integer; user_opional_info_gender_id_updates integer; user_opional_info_ethnicity_id_updates integer; user_opional_info_date_modified_updates integer;
			  user_opional_info_purged_updates integer; user_opional_info_disability_updates integer; user_opional_info_disability_desc_updates integer; user_opional_info_ex_convict_updates integer; user_opional_info_vectim_of_terrorism_updates integer; user_opional_info_employment_equity_candidate_updates integer;
			  user_opional_info_new_customer_update integer; user_opional_info_target_product_type_id_updates integer; user_opional_info_karma_company_size_id_updates integer; user_opional_info_copmany_group_id_updates integer; user_opional_info_datasource_id_updates integer;
			  --"MediaBay"."REF.JS.USER.REF.SCHOOL.DETAILS"
			  user_ref_school_details_inserts integer;
			  --"MediaBay"."JS_U_(05)_UserEducationDetails"
			  user_education_education_level_id_updates integer; user_education_ref_school_id_updates integer; user_education_start_month_updates integer; user_education_start_year_updates integer; user_education_completed_day_updates integer; user_education_completed_month_updates integer; 
			  user_education_completed_year_updates integer; user_education_education_subject_updates integer; user_education_education_summary_updates integer; user_education_gpa_updates integer; user_education_city_updates integer; user_education_state_updates integer; user_education_country_id_updates integer;
			  user_education_resume_education_id_updates integer; user_education_resume_id_updates integer; user_education_date_modified_updates integer; user_education_date_deleted_updates integer; user_education_etl_date_updates integer;
			  --"MediaBay"."REF.JS.USER.EDUCATION.FIELD.OF.STUDY"
			  user_ref_education_field_inserted integer;
			--"MediaBay"."JS_U_(05.1)_UserEducationField"
                       user_education_field_inserted integer;	  
		BEGIN
-----------------INSERT DATA INTO REF TABLES
			  -- "MediaBay"."REF.JS.USER.LOCATION.DETAILS"
			 INSERT INTO "MediaBay"."REF.JS.USER.LOCATION.DETAILS" (location_id, continent_id, continent_name, continent_add, country_id, country_name, country_abb, state_id, state_name, state_abb, city_id, city_name, parent_location_id, date_deleted, candidate_search_eligible, etl_date, datasource_id)
			 SELECT DISTINCT ON (location_id) location_id, continent_id, continent_name, continent_add, country_id, country_name, country_abb, state_id, state_name, state_abb, city_id, city_name, parent_location_id, date_deleted, candidate_search_eligible, etl_date, datasource_id
			 FROM "MediaBay"."REF.STG.LOCATION.DETAILS"
			 ON CONFLICT DO NOTHING;
---------------- UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails"
			  --"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- name_prefix_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET name_prefix_id = ST.name_prefix_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.name_prefix_id <> ST.name_prefix_id
						AND ST.name_prefix_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_name_prefix_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- first_name
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT
						SET first_name = initcap (trim(both ' ' from ST.first_name))
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST
						WHERE
						ST.user_id = RT.user_id
						AND RT.first_name <> initcap (trim(both ' ' from ST.first_name))
						AND initcap (trim(both ' ' from ST.first_name)) IS NOT NULL
						AND initcap (trim(both ' ' from ST.first_name)) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_first_name_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- middle_name
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET middle_name = initcap (trim(both ' ' from ST.middle_name))
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.middle_name <> initcap (trim(both ' ' from ST.middle_name))
						AND initcap (trim(both ' ' from ST.middle_name)) IS NOT NULL
						AND initcap (trim(both ' ' from ST.middle_name)) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_middle_name_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- last_name
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET last_name = initcap (trim(both ' ' from ST.last_name))
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.last_name <> initcap (trim(both ' ' from ST.last_name))
						AND initcap (trim(both ' ' from ST.last_name)) IS NOT NULL
						AND initcap (trim(both ' ' from ST.last_name)) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_last_name_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- name_suffix
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET name_suffix = trim(both ' ' from ST.name_suffix)
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.name_suffix <> trim(both ' ' from ST.name_suffix)
						AND trim(both ' ' from ST.name_suffix) IS NOT NULL
						AND trim(both ' ' from ST.name_suffix) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_name_suffix_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- email_address
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT
						SET email_address = trim(both ' ' from ST.email_address)
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST
						WHERE
						ST.user_id = RT.user_id
						AND RT.email_address <> trim(both ' ' from ST.email_address)
						AND trim(both ' ' from ST.email_address) IS NOT NULL
						AND trim(both ' ' from ST.email_address) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_email_address_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- country_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET country_id = ST.country_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.country_id <> ST.country_id
						AND ST.country_id IS NOT NULL
						AND ST.country_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_country_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- state_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET state_id = ST.state_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.state_id <> ST.state_id
						AND ST.state_id IS NOT NULL
						AND ST.state_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_state_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- us_zip5
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET us_zip5 = ST.us_zip5
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.us_zip5 <> ST.us_zip5
						AND ST.us_zip5 IS NOT NULL
						AND ST.us_zip5 <> '0';
				GET DIAGNOSTICS jobseaker_user_info_us_zip5_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- location_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET location_id = ST.location_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.location_id <> ST.location_id
						AND ST.location_id IS NOT NULL
						AND ST.location_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_location_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- confidential
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET confidential = ST.confidential
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.confidential <> ST.confidential
						AND ST.confidential IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_confidential_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- disabled
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET disabled = ST.disabled
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.disabled <> ST.disabled
						AND ST.disabled IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_disabled_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- channel_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET channel_id = ST.channel_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.channel_id <> ST.channel_id
						AND ST.channel_id IS NOT NULL
						AND ST.channel_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_channel_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- career_level_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET career_level_id = ST.career_level_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.career_level_id <> ST.career_level_id
						AND ST.career_level_id IS NOT NULL
						AND ST.career_level_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_career_level_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- available_time_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET available_time_id = ST.available_time_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.available_time_id <> ST.available_time_id
						AND ST.available_time_id IS NOT NULL
						AND ST.available_time_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_available_time_id_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- available_day
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET available_day = ST.available_day
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.available_day <> ST.available_day
						AND ST.available_day IS NOT NULL
						AND ST.available_day <> '0';
				GET DIAGNOSTICS jobseaker_user_info_available_day_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- available_month
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET available_month = ST.available_month
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.available_month <> ST.available_month
						AND ST.available_month IS NOT NULL
						AND ST.available_month <> '0';
				GET DIAGNOSTICS jobseaker_user_info_available_month_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- available_year
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET available_year = ST.available_year
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.available_year <> ST.available_year
						AND ST.available_year IS NOT NULL
						AND ST.available_year <> '0';
				GET DIAGNOSTICS jobseaker_user_info_available_year_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- company
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET company = initcap(trim(both ' ' from ST.company))
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.company <> initcap(trim(both ' ' from ST.company))
						AND initcap(trim(both ' ' from ST.company)) IS NOT NULL
						AND initcap(trim(both ' ' from ST.company)) <> '0';
				GET DIAGNOSTICS jobseaker_user_info_company_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- date_modified
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET date_modified = ST.date_modified
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.date_modified <> ST.date_modified
						AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_date_modified_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- date_deleted
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET date_deleted = ST.date_deleted
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.date_deleted <> ST.date_deleted
						AND ST.date_deleted IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_date_deleted_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- etl_date
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET etl_date = ST.etl_date
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.etl_date <> ST.etl_date
						AND ST.etl_date IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_info_etl_date_updates = ROW_COUNT;
				--"MediaBay"."JOBSEAKER_USER_INFO_UPDATE"() -- created_channel_id
			      UPDATE "MediaBay"."JS_U_(01)_UserInfoDetails" RT 
						SET created_channel_id = ST.created_channel_id
			      FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.created_channel_id <> ST.created_channel_id
						AND ST.created_channel_id IS NOT NULL
						AND ST.created_channel_id <> '0';
				GET DIAGNOSTICS jobseaker_user_info_created_channel_id_updates = ROW_COUNT;
---------------------"MediaBay"."JS_U_(01.2)_UserAdditionalInfo"
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --contact_prefered_format_id
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET contact_prefered_format_id = ST.contact_prefered_format_id
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.contact_prefered_format_id <> ST.contact_prefered_format_id
						AND ST.contact_prefered_format_id <> '0'
						AND ST.contact_prefered_format_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_contact_prefered_format_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --year_experience_id
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET year_experience_id = ST.year_experience_id
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.year_experience_id <> ST.year_experience_id
						AND ST.year_experience_id <> '0'
						AND ST.year_experience_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_year_experience_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --us_military_involvement_id
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET us_military_involvement_id = ST.us_military_involvement_id
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.us_military_involvement_id <> ST.us_military_involvement_id
						AND ST.us_military_involvement_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_us_military_involvement_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --date_modified
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET date_modified = ST.date_modified
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.date_modified <> ST.date_modified
						AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_date_modified_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --years_user_exp_id_project_leadership
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET years_user_exp_id_project_leadership = ST.years_user_exp_id_project_leadership
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.years_user_exp_id_project_leadership <> ST.years_user_exp_id_project_leadership
						AND ST.years_user_exp_id_project_leadership IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_years_user_exp_id_project_leadership_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --year_user_exp_id_management
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET year_user_exp_id_management = ST.year_user_exp_id_management
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.year_user_exp_id_management <> ST.year_user_exp_id_management
						AND ST.year_user_exp_id_management IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_year_user_exp_id_management_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --local_location_id
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET local_location_id = ST.local_location_id
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.local_location_id <> ST.local_location_id
						AND ST.local_location_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_local_location_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo" --local_location_id
				UPDATE "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" RT 
						SET datasource_id = ST.datasource_id
			       FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.datasource_id <> ST.datasource_id
						AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS jobseaker_user_datasource_id_updates = ROW_COUNT;
				
---------------------"MediaBay"."JS_U_(01.3)_UserOptionalInfo"
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--country_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET country_id = ST.country_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.country_id <> ST.country_id
						AND ST.country_id IS NOT NULL
						AND ST.country_id <> '0';
				GET DIAGNOSTICS user_opional_info_country_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--dob_day
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET dob_day = ST.dob_day
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.dob_day <> ST.dob_day
						AND ST.dob_day IS NOT NULL
						AND ST.dob_day <> '0';
				GET DIAGNOSTICS user_opional_info_dob_day_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--dob_month
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET dob_month = ST.dob_month
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.dob_month <> ST.dob_month
						AND ST.dob_month IS NOT NULL
						AND ST.dob_month <> '0';
				GET DIAGNOSTICS user_opional_info_dob_month_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--dob_year
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET dob_year = ST.dob_year
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.dob_year <> ST.dob_year
						AND ST.dob_year IS NOT NULL
						AND ST.dob_year <> '0';
				GET DIAGNOSTICS user_opional_info_dob_year_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--gender_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET gender_id = ST.gender_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.gender_id <> ST.gender_id
						AND ST.gender_id <> '0'
						AND ST.gender_id IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_gender_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--ethnicity_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET ethnicity_id = ST.ethnicity_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.ethnicity_id <> ST.ethnicity_id
						AND ST.ethnicity_id IS NOT NULL
						AND ST.ethnicity_id <> '0';
				GET DIAGNOSTICS user_opional_info_ethnicity_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--date_modified
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET date_modified = ST.date_modified
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.date_modified <> ST.date_modified
						AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_date_modified_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--purged
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET purged = ST.purged
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.purged <> ST.purged
						AND ST.purged IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_purged_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--disability
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET disability = ST.disability
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.disability <> ST.disability
						AND ST.disability IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_disability_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--disability_desc
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET disability_desc = ST.disability_desc
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.disability_desc <> ST.disability_desc
						AND ST.disability_desc IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_disability_desc_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--ex_convict
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET ex_convict = ST.ex_convict
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.ex_convict <> ST.ex_convict
						AND ST.ex_convict IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_ex_convict_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--vectim_of_terrorism
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET vectim_of_terrorism = ST.vectim_of_terrorism
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.vectim_of_terrorism <> ST.vectim_of_terrorism
						AND ST.vectim_of_terrorism IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_vectim_of_terrorism_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--employment_equity_candidate
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET employment_equity_candidate = ST.employment_equity_candidate
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.employment_equity_candidate <> ST.employment_equity_candidate
						AND ST.employment_equity_candidate IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_employment_equity_candidate_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--new_customer
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET new_customer = ST.new_customer
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.new_customer <> ST.new_customer
						AND ST.new_customer IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_new_customer_update = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--target_product_type_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET target_product_type_id = ST.target_product_type_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.target_product_type_id <> ST.target_product_type_id
						AND ST.target_product_type_id IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_target_product_type_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--karma_company_size_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET karma_company_size_id = ST.karma_company_size_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.karma_company_size_id <> ST.karma_company_size_id
						AND ST.karma_company_size_id IS NOT NULL
						AND ST.karma_company_size_id <> '0';
				GET DIAGNOSTICS user_opional_info_karma_company_size_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--copmany_group_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET copmany_group_id = ST.copmany_group_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.copmany_group_id <> ST.copmany_group_id
						AND ST.copmany_group_id IS NOT NULL
						AND ST.copmany_group_id <> '0';
				GET DIAGNOSTICS user_opional_info_copmany_group_id_updates = ROW_COUNT;
			-----"MediaBay"."JS_U_(01.3)_UserOptionalInfo"--copmany_group_id
				UPDATE "MediaBay"."JS_U_(01.3)_UserOptionalInfo" RT 
						SET datasource_id = ST.datasource_id
			       FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" ST 
						WHERE
						ST.user_id = RT.user_id
						AND RT.datasource_id <> ST.datasource_id
						AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS user_opional_info_datasource_id_updates = ROW_COUNT;
---------------------"MediaBay"."REF.JS.USER.REF.SCHOOL.DETAILS"
				INSERT INTO "MediaBay"."REF.JS.USER.REF.SCHOOL.DETAILS" (ref_school_id, school_name, ref_geo_id, reference_status_id, date_modified, user_count, datasource_id)
       			SELECT DISTINCT ON (ref_school_id) ref_school_id, school_name, ref_geo_id, reference_status_id, date_modified, user_count, datasource_id
				FROM "MediaBay"."REF.STG.USER.REF.SCHOOL.DETAILS"
				ON CONFLICT ON CONSTRAINT ref_school_pkey DO UPDATE
					SET school_name = EXCLUDED.school_name,
						ref_geo_id = EXCLUDED.ref_geo_id,
						reference_status_id = EXCLUDED.reference_status_id,
						date_modified = EXCLUDED.date_modified,
						user_count = EXCLUDED.user_count;
				GET DIAGNOSTICS user_ref_school_details_inserts = ROW_COUNT;
------------------------"MediaBay"."JS_U_(05)_UserEducationDetails"
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- education_level_id
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET education_level_id = ST.education_level_id
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.education_level_id <> ST.education_level_id
						AND ST.education_level_id <> '0'
						AND ST.education_level_id IS NOT NULL;
				GET DIAGNOSTICS user_education_education_level_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- ref_school_id
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET ref_school_id = ST.ref_school_id
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.ref_school_id <> ST.ref_school_id
						AND ST.ref_school_id <> '0'
						AND ST.ref_school_id IS NOT NULL;
				GET DIAGNOSTICS user_education_ref_school_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- start_month
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET start_month = ST.start_month
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.start_month <> ST.start_month
						AND ST.start_month <> '0'
						AND ST.start_month IS NOT NULL;
				GET DIAGNOSTICS user_education_start_month_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- start_year
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET start_year = ST.start_year
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.start_year <> ST.start_year
						AND ST.start_year <> '0'
						AND ST.start_year IS NOT NULL;
				GET DIAGNOSTICS user_education_start_year_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- completed_day
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET completed_day = ST.completed_day
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.completed_day <> ST.completed_day
						AND ST.completed_day <> '0'
						AND ST.completed_day IS NOT NULL;
				GET DIAGNOSTICS user_education_completed_day_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- completed_month
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET completed_month = ST.completed_month
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.completed_month <> ST.completed_month
						AND ST.completed_month <> '0'
						AND ST.completed_month IS NOT NULL;
				GET DIAGNOSTICS user_education_completed_month_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- completed_year
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET completed_year = ST.completed_year
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.completed_year <> ST.completed_year
						AND ST.completed_year <> '0'
						AND ST.completed_year IS NOT NULL;
				GET DIAGNOSTICS user_education_completed_year_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- education_subject
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET education_subject = trim(both ' ' from ST.education_subject)
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.education_subject <> trim(both ' ' from ST.education_subject)
						AND trim(both ' ' from ST.education_subject) <> '0'
						AND trim(both ' ' from ST.education_subject) IS NOT NULL;
				GET DIAGNOSTICS user_education_education_subject_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- education_summary
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET education_summary = trim(both ' ' from ST.education_summary)
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.education_summary <> ST.education_summary
						AND trim(both ' ' from ST.education_summary) <> '0'
						AND trim(both ' ' from ST.education_summary) IS NOT NULL;
				GET DIAGNOSTICS user_education_education_summary_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- gpa
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET gpa = trim(both ' ' from ST.gpa)
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.gpa <> ST.gpa
						AND trim(both ' ' from ST.gpa) <> '0'
						AND trim(both ' ' from ST.gpa) IS NOT NULL;
				GET DIAGNOSTICS user_education_gpa_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- city
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET city = initcap(trim(both ' ' from ST.city))
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.city <> ST.city
						AND initcap(trim(both ' ' from ST.city)) <> '0'
						AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
				GET DIAGNOSTICS user_education_city_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- state
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET state = initcap(trim(both ' ' from ST.state))
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.state <> ST.state
						AND initcap(trim(both ' ' from ST.state)) <> '0'
						AND initcap(trim(both ' ' from ST.state)) IS NOT NULL;
				GET DIAGNOSTICS user_education_state_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- country_id
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET country_id = ST.country_id
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.country_id <> ST.country_id
						AND ST.country_id <> '0'
						AND ST.country_id IS NOT NULL;
				GET DIAGNOSTICS user_education_country_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- resume_education_id
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET resume_education_id = ST.resume_education_id
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.resume_education_id <> ST.resume_education_id
						AND ST.resume_education_id <> '0'
						AND ST.resume_education_id IS NOT NULL;
				GET DIAGNOSTICS user_education_resume_education_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- resume_id
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET resume_id = ST.resume_id
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.resume_id <> ST.resume_id
						AND ST.resume_id <> '0'
						AND ST.resume_id IS NOT NULL;
				GET DIAGNOSTICS user_education_resume_id_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- date_modified
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET date_modified = ST.date_modified
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.date_modified <> ST.date_modified
						AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS user_education_date_modified_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- date_deleted
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET date_deleted = ST.date_deleted
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.date_deleted <> ST.date_deleted
						AND ST.date_deleted IS NOT NULL;
				GET DIAGNOSTICS user_education_date_deleted_updates = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails" -- etl_date
			      UPDATE "MediaBay"."JS_U_(05)_UserEducationDetails" RT 
						SET etl_date = ST.etl_date
			      FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST 
						WHERE
						ST.user_education_id = RT.user_education_id
						AND RT.etl_date <> ST.etl_date
						AND ST.etl_date IS NOT NULL;
				GET DIAGNOSTICS user_education_etl_date_updates = ROW_COUNT;
---------------------"MediaBay"."REF.JS.USER.EDUCATION.FIELD.OF.STUDY"
				INSERT INTO "MediaBay"."REF.JS.USER.REF.FIELD.OF.STUDY" (ref_field_of_study_id, field_of_study_name, reference_status_id, user_count, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (ref_field_of_study_id) ref_field_of_study_id, field_of_study_name, reference_status_id, user_count, date_modified, etl_date, datasource_id
				FROM "MediaBay"."REF.STG.REF.FIELD.OF.STUDY"
				ON CONFLICT ON CONSTRAINT ref_field_of_study_pkey DO UPDATE
					SET field_of_study_name = EXCLUDED.field_of_study_name,
						reference_status_id = EXCLUDED.reference_status_id,
						user_count = EXCLUDED.user_count,
						date_modified = EXCLUDED.date_modified,
						etl_date = EXCLUDED.etl_date;
				GET DIAGNOSTICS user_ref_education_field_inserted = ROW_COUNT;
---------------------"MediaBay"."JS_U_(05.1)_UserEducationField"
				DELETE FROM "MediaBay"."JS_U_STG_(05.1)_UserEducationField" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(05)_UserEducationDetails" RT WHERE ST.user_education_id = RT.user_education_id);
				INSERT INTO "MediaBay"."JS_U_(05.1)_UserEducationField" (user_education_field_of_study_id, user_education_id, ref_field_of_study_id, ref_field_of_study_translation_id, user_entered_field_of_study, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (user_education_field_of_study_id) user_education_field_of_study_id, user_education_id, ref_field_of_study_id, ref_field_of_study_translation_id, user_entered_field_of_study, date_modified, etl_date, datasource_id
				FROM "MediaBay"."JS_U_STG_(05.1)_UserEducationField"
				ON CONFLICT ON CONSTRAINT user_education_field_of_study_pkey DO UPDATE 
						SET user_education_id = EXCLUDED.user_education_id,
							ref_field_of_study_id = EXCLUDED.ref_field_of_study_id,
							ref_field_of_study_translation_id = EXCLUDED.ref_field_of_study_translation_id,
							user_entered_field_of_study = EXCLUDED.user_entered_field_of_study,
							date_modified = EXCLUDED.date_modified,
							etl_date = EXCLUDED.etl_date;
				GET DIAGNOSTICS user_education_field_inserted = ROW_COUNT;
				RETURN QUERY SELECT
				jobseaker_user_info_name_prefix_id_updates, jobseaker_user_info_first_name_updates, jobseaker_user_info_middle_name_updates, jobseaker_user_info_last_name_updates, jobseaker_user_info_name_suffix_updates, jobseaker_user_info_email_address_updates, 
				jobseaker_user_info_country_id_updates, jobseaker_user_info_state_id_updates, jobseaker_user_info_us_zip5_updates, jobseaker_user_info_location_id_updates, jobseaker_user_info_confidential_updates, jobseaker_user_info_disabled_updates, jobseaker_user_info_channel_id_updates, 
				jobseaker_user_info_career_level_id_updates, jobseaker_user_info_available_time_id_updates, jobseaker_user_info_available_day_updates, jobseaker_user_info_available_month_updates, jobseaker_user_info_available_year_updates, jobseaker_user_info_company_updates, 
				jobseaker_user_info_date_modified_updates, jobseaker_user_info_date_deleted_updates, jobseaker_user_info_etl_date_updates, jobseaker_user_info_created_channel_id_updates,
---------------------"MediaBay"."JS_U_(01.2)_UserAdditionalInfo"
				jobseaker_user_contact_prefered_format_id_updates, jobseaker_user_year_experience_id_updates, jobseaker_user_us_military_involvement_id_updates, jobseaker_user_date_modified_updates, jobseaker_user_years_user_exp_id_project_leadership_updates, jobseaker_user_year_user_exp_id_management_updates, 
				jobseaker_user_local_location_id_updates, jobseaker_user_datasource_id_updates, 
---------------------"MediaBay"."JS_U_(01.3)_UserOptionalInfo"
				user_opional_info_country_id_updates, user_opional_info_dob_day_updates, user_opional_info_dob_month_updates, user_opional_info_dob_year_updates, user_opional_info_gender_id_updates, 
				user_opional_info_ethnicity_id_updates, user_opional_info_date_modified_updates, user_opional_info_purged_updates, user_opional_info_disability_updates, user_opional_info_disability_desc_updates, user_opional_info_ex_convict_updates, user_opional_info_vectim_of_terrorism_updates, 
				user_opional_info_employment_equity_candidate_updates, user_opional_info_new_customer_update, user_opional_info_target_product_type_id_updates, user_opional_info_karma_company_size_id_updates, user_opional_info_copmany_group_id_updates, user_opional_info_datasource_id_updates, 
				--"MediaBay"."JS_U_(05.1)_UserEducationShool&Field"
				user_ref_school_details_inserts, user_education_education_level_id_updates, user_education_ref_school_id_updates, 
---------------------"MediaBay"."JS_U_(05)_UserEducationDetails"
				user_education_start_month_updates, user_education_start_year_updates, user_education_completed_day_updates, user_education_completed_month_updates, 
				user_education_completed_year_updates, user_education_education_subject_updates, user_education_education_summary_updates, user_education_gpa_updates, user_education_city_updates, user_education_state_updates, user_education_country_id_updates,
				user_education_resume_education_id_updates, user_education_resume_id_updates, user_education_date_modified_updates, user_education_date_deleted_updates, user_education_etl_date_updates,
				--"MediaBay"."REF.JS.USER.EDUCATION.FIELD.OF.STUDY"
				user_ref_education_field_inserted,
				--"MediaBay"."JS_U_(05.1)_UserEducationField"
				user_education_field_inserted;
		END;

$$;
