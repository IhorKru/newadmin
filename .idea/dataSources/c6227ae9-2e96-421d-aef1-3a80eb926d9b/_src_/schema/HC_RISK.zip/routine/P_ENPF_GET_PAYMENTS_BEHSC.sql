CREATE procedure p_enpf_get_payments_behsc
  is
    v_dt date;
    v_max_wd date;
    v_act_dt date := trunc(sysdate);
    v_iin varchar2(12);
    n integer;
  begin
/*    
-- Create table
create table TMP_I_MT102_DC2_BEHSC
(
  i_mt   NUMBER not null,
  assign VARCHAR2(500),
  summ   NUMBER(20,4) not null,
  rnn    VARCHAR2(12)
)
tablespace RISK
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 100M
    next 10M
    minextents 1
    maxextents unlimited
  );
*/      
    execute immediate 'truncate table t_enpf_for_scoring_validation';

    select max(dt_load), max(work_date) into v_dt, v_max_wd from main.working_date;

    execute immediate 'truncate table tmp_i_mt102_dc2_behsc';
    n := 0;
    for rec in (select distinct iin from t_enpf_clients_for_behscore)
    loop
      v_iin := rec.iin;

      insert into tmp_i_mt102_dc2_behsc
      (
         i_mt
        ,assign
        ,summ
        ,rnn
      )
      select
         t2.i_mt
        ,t2.assign
        ,t2.summ
        ,v_iin
      from
        main.i_mt102_dc2 t2
      where
        t2.rnn = v_iin
      ;

      n := n+1;
      if mod(n,50000) = 0 then
        
        commit;
        
        dbms_stats.gather_table_stats('HC_RISK','TMP_I_MT102_DC2_BEHSC');

        insert into t_enpf_for_scoring_validation
        select
           t.rnn
          ,grid.dt

          --sum of payments for the last n months
          ,sum(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) as amt_3m
          ,sum(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) as amt_6m
          ,sum(case when wd.work_date between add_months(grid.dt,-9) and grid.dt then t.summ end) as amt_9m
          ,sum(case when wd.work_date between add_months(grid.dt,-12) and grid.dt then t.summ end) as amt_12m

          --count of months with payments for the last n months
          ,count(distinct case when wd.work_date between add_months(grid.dt,-3) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_3m
          ,count(distinct case when wd.work_date between add_months(grid.dt,-6) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_6m
          ,count(distinct case when wd.work_date between add_months(grid.dt,-9) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_9m
          ,count(distinct case when wd.work_date between add_months(grid.dt,-12) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_12m

          --number of payments for the last n months
          ,count(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then 1 end) as cnt_payments_3m
          ,count(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then 1 end) as cnt_payments_6m
          ,count(case when wd.work_date between add_months(grid.dt,-9) and grid.dt then 1 end) as cnt_payments_9m
          ,count(case when wd.work_date between add_months(grid.dt,-12) and grid.dt then 1 end) as cnt_payments_12m

         --salary trend
          ,sum(case when wd.work_date between add_months(grid.dt,-2) and grid.dt then t.summ end) / sum(case when wd.work_date between add_months(grid.dt,-4) and add_months(grid.dt,-2) then t.summ end) as salary_trend_2_4
          ,sum(case when wd.work_date between add_months(grid.dt,-4) and grid.dt then t.summ end) / sum(case when wd.work_date between add_months(grid.dt,-8) and add_months(grid.dt,-4) then t.summ end) as salary_trend_4_8

          ,max(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) / avg(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) as max_per_avg_3
          ,max(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) / avg(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) as max_per_avg_6

         --employers
          ,count(distinct case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.assign end) as cnt_unique_empl_3
          ,count(distinct case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.assign end) as cnt_unique_empl_6
          ,count(distinct case when wd.work_date between add_months(grid.dt,-9) and grid.dt then t.assign end) as cnt_unique_empl_9
          ,count(distinct case when wd.work_date between add_months(grid.dt,-12) and grid.dt then t.assign end) as cnt_unique_empl_12

          ,trunc(min(months_between(grid.dt,wd.work_date))) as cnt_mths_last_salary

          ,sum(case when wd.work_date > grid.dt then t.summ end) as amt_last_early

          ,v_dt as dt_load
          ,v_max_wd as max_work_date
          ,v_act_dt as action_date
        from
               tmp_i_mt102_dc2_behsc t
          join main.i_mt im on im.i_mt = t.i_mt and im.f70_knp = '010'
          join main.working_date wd on wd.working_date = im.working_date and wd.dt_load = im.dt_load
          --join (select sysdate as dt from dual) grid on wd.work_date < grid.dt
          join (select v_max_wd as dt from dual) grid on wd.work_date < grid.dt+1
        where
          im.dt_load = v_dt
        group by
           t.rnn
          ,grid.dt
        ;

        commit;

        execute immediate 'truncate table tmp_i_mt102_dc2_behsc';
        
      end if;
      
    end loop;

    commit;
    dbms_stats.gather_table_stats('HC_RISK','TMP_I_MT102_DC2_BEHSC');

    insert into t_enpf_for_scoring_validation
    select
       t.rnn
      ,grid.dt

      --sum of payments for the last n months
      ,sum(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) as amt_3m
      ,sum(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) as amt_6m
      ,sum(case when wd.work_date between add_months(grid.dt,-9) and grid.dt then t.summ end) as amt_9m
      ,sum(case when wd.work_date between add_months(grid.dt,-12) and grid.dt then t.summ end) as amt_12m

      --count of months with payments for the last n months
      ,count(distinct case when wd.work_date between add_months(grid.dt,-3) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_3m
      ,count(distinct case when wd.work_date between add_months(grid.dt,-6) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_6m
      ,count(distinct case when wd.work_date between add_months(grid.dt,-9) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_9m
      ,count(distinct case when wd.work_date between add_months(grid.dt,-12) and grid.dt then trunc(wd.work_date,'mm') end) as cnt_mths_wp_12m

      --number of payments for the last n months
      ,count(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then 1 end) as cnt_payments_3m
      ,count(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then 1 end) as cnt_payments_6m
      ,count(case when wd.work_date between add_months(grid.dt,-9) and grid.dt then 1 end) as cnt_payments_9m
      ,count(case when wd.work_date between add_months(grid.dt,-12) and grid.dt then 1 end) as cnt_payments_12m

     --salary trend
      ,sum(case when wd.work_date between add_months(grid.dt,-2) and grid.dt then t.summ end) / sum(case when wd.work_date between add_months(grid.dt,-4) and add_months(grid.dt,-2) then t.summ end) as salary_trend_2_4
      ,sum(case when wd.work_date between add_months(grid.dt,-4) and grid.dt then t.summ end) / sum(case when wd.work_date between add_months(grid.dt,-8) and add_months(grid.dt,-4) then t.summ end) as salary_trend_4_8

      ,max(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) / avg(case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.summ end) as max_per_avg_3
      ,max(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) / avg(case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.summ end) as max_per_avg_6

     --employers
      ,count(distinct case when wd.work_date between add_months(grid.dt,-3) and grid.dt then t.assign end) as cnt_unique_empl_3
      ,count(distinct case when wd.work_date between add_months(grid.dt,-6) and grid.dt then t.assign end) as cnt_unique_empl_6
      ,count(distinct case when wd.work_date between add_months(grid.dt,-9) and grid.dt then t.assign end) as cnt_unique_empl_9
      ,count(distinct case when wd.work_date between add_months(grid.dt,-12) and grid.dt then t.assign end) as cnt_unique_empl_12

      ,trunc(min(months_between(grid.dt,wd.work_date))) as cnt_mths_last_salary

      ,sum(case when wd.work_date > grid.dt then t.summ end) as amt_last_early

      ,v_dt as dt_load
      ,v_max_wd as max_work_date
      ,v_act_dt as action_date
    from
           tmp_i_mt102_dc2_behsc t
      join main.i_mt im on im.i_mt = t.i_mt and im.f70_knp = '010'
      join main.working_date wd on wd.working_date = im.working_date and wd.dt_load = im.dt_load
      --join (select sysdate as dt from dual) grid on wd.work_date < grid.dt
      join (select v_max_wd as dt from dual) grid on wd.work_date < grid.dt+1
    where
      im.dt_load = v_dt
    group by
       t.rnn
      ,grid.dt
    ;

    commit;

    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_FOR_SCORING_VALIDATION');
  end;
/
