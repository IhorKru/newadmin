CREATE PROCEDURE `rds_set_configuration`(`name` VARCHAR(30), `value` INT(11))
  BEGIN
   DECLARE sql_logging BOOLEAN;
   SELECT @@sql_log_bin INTO sql_logging;
   SET @@sql_log_bin = OFF;
   UPDATE mysql.rds_configuration
   SET mysql.rds_configuration.value = value
   WHERE BINARY mysql.rds_configuration.name = BINARY name;
   SET @@sql_log_bin = sql_logging;
END