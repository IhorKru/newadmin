CREATE procedure p_enpf_gather_stats(p_table_name varchar2)
  is
  begin
    dbms_stats.gather_table_stats('HC_RISK',upper(p_table_name));
  end;
/
