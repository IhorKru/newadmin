CREATE procedure p_enpf_get_client_data
  is
    v_dt date;
  begin
    execute immediate 'truncate table t_enpf_client_contacts';

    select max(dt_load) into v_dt from main.working_date;

    insert /*+ append */ into t_enpf_client_contacts
    (
       iin
      ,phone_work
      ,phone_home
      ,phone_mobile
      ,address_registration
    )
    select
      t4.iin,
      np.phone_work,
      np.phone,
      np.phone_mobile,
      nvl(
          np.address,
          nvl(np.adress_post_index, np.pind)||', '||r.name||', '||d.name||', '||gc.name||', '||
          np.adress_street||', дом '||np.adress_house_num||', кв. '||np.adress_flat_num
         )
    from
                t_enpf_parameters_of_request t4
           join main.g_nat_person np on np.idn = t4.iin and np.dt_load = v_dt
      left join main.g_district d on d.g_district = np.adress_g_district and d.dt_load = v_dt
      left join main.g_region r on r.g_region = d.g_region and r.dt_load = v_dt
      left join main.g_city gc on gc.g_city = np.adress_g_city and gc.dt_load = v_dt;

    commit;

    dbms_stats.gather_table_stats('HC_RISK','T_ENPF_CLIENT_CONTACTS');
  end;
/
